#ifndef _EXT_COLORS_H_
#define _EXT_COLORS_H_

#define P_WHITE 0
#define P_BLACK 1
#define P_GRAYULITE 20
#define P_GRAYVLITE 21
#define P_GRAYLITE 22
#define P_GRAYMED 25
#define P_GRAYDARK 27
#define P_COLOR1 4
#define P_COLOR16 19
#define P_YELLOW 32
#define P_RED 33

#endif /* _EXT_COLORS_H_ */